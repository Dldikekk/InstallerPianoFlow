using System;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace PianoFlowSetup {
  class SetupForm : Form {
    CheckBox desktop; Label status; Button install; string appDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","PianoFlow");
    public SetupForm(){Text="Установка PianoFlow";ClientSize=new Size(560,420);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(16,23,34);ForeColor=Color.White;Font=new Font("Segoe UI",10);try{Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);}catch{}
      Panel hero=new Panel{Dock=DockStyle.Top,Height=185,BackColor=Color.FromArgb(27,43,58)};Controls.Add(hero);hero.Paint+=(s,e)=>{e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;using(var b=new SolidBrush(Color.FromArgb(43,190,151)))e.Graphics.FillEllipse(b,440,25,58,58);using(var b=new SolidBrush(Color.FromArgb(90,255,255,255)))e.Graphics.FillEllipse(b,452,37,34,34);};
      Label title=new Label{Text="PianoFlow",Font=new Font("Segoe UI",28,FontStyle.Bold),ForeColor=Color.White,AutoSize=true,Location=new Point(32,30)};hero.Controls.Add(title);
      Label sub=new Label{Text="Пианино и MIDI — без регистрации и ограничений",Font=new Font("Segoe UI",11),ForeColor=Color.FromArgb(185,201,215),AutoSize=true,Location=new Point(36,91)};hero.Controls.Add(sub);
      Label k=new Label{Text="♩   ♫   ♬",Font=new Font("Segoe UI",25,FontStyle.Bold),ForeColor=Color.FromArgb(43,190,151),AutoSize=true,Location=new Point(36,125)};hero.Controls.Add(k);
      Label pathLabel=new Label{Text="Установка для текущего пользователя",ForeColor=Color.FromArgb(210,220,229),AutoSize=true,Location=new Point(34,212)};Controls.Add(pathLabel);
      Label path=new Label{Text=appDir,ForeColor=Color.FromArgb(43,190,151),AutoSize=false,Location=new Point(34,239),Size=new Size(490,24)};Controls.Add(path);
      desktop=new CheckBox{Text="Создать ярлык на рабочем столе",Checked=true,AutoSize=true,Location=new Point(34,280),ForeColor=Color.White};Controls.Add(desktop);
      status=new Label{Text="",Location=new Point(34,322),Size=new Size(330,25),ForeColor=Color.FromArgb(185,201,215)};Controls.Add(status);
      install=new Button{Text="Установить",Location=new Point(386,314),Size=new Size(140,48),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(43,190,151),ForeColor=Color.FromArgb(12,25,32),Font=new Font("Segoe UI",11,FontStyle.Bold)};install.FlatAppearance.BorderSize=0;install.Click+=(s,e)=>{if(install.Text=="Запустить PianoFlow"){try{Process.Start(new ProcessStartInfo(Path.Combine(appDir,"PianoFlow.exe")){UseShellExecute=true,WorkingDirectory=appDir});}catch{}Close();}else Install();};Controls.Add(install);
      Label foot=new Label{Text="Офлайн • Windows 10/11",ForeColor=Color.FromArgb(105,125,147),AutoSize=true,Location=new Point(34,380)};Controls.Add(foot);
    }
    byte[] Resource(string name){using(Stream s=Assembly.GetExecutingAssembly().GetManifestResourceStream(name)){if(s==null)throw new Exception("Не найден файл установки: "+name);using(MemoryStream m=new MemoryStream()){s.CopyTo(m);return m.ToArray();}}}
    void Shortcut(string link,string target,string args){Type t=Type.GetTypeFromProgID("WScript.Shell");dynamic shell=Activator.CreateInstance(t);dynamic sc=shell.CreateShortcut(link);sc.TargetPath=target;sc.Arguments=args;sc.WorkingDirectory=appDir;sc.IconLocation=Path.Combine(appDir,"PianoFlow.exe")+",0";sc.Description="PianoFlow — piano and MIDI practice";sc.Save();Marshal.FinalReleaseComObject(sc);Marshal.FinalReleaseComObject(shell);}
    void Install(){try{install.Enabled=false;status.Text="Копирую файлы…";Directory.CreateDirectory(appDir);File.WriteAllBytes(Path.Combine(appDir,"PianoFlow.exe"),Resource("PianoFlowSetup.PianoFlow.exe"));File.WriteAllBytes(Path.Combine(appDir,"Uninstall.exe"),Resource("PianoFlowSetup.Uninstall.exe"));File.WriteAllBytes(Path.Combine(appDir,"PianoFlow.ico"),Resource("PianoFlowSetup.PianoFlow.ico"));
      string menu=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"PianoFlow");Directory.CreateDirectory(menu);Shortcut(Path.Combine(menu,"PianoFlow.lnk"),Path.Combine(appDir,"PianoFlow.exe"),"");Shortcut(Path.Combine(menu,"Uninstall PianoFlow.lnk"),Path.Combine(appDir,"Uninstall.exe"),"");if(desktop.Checked)Shortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"PianoFlow.lnk"),Path.Combine(appDir,"PianoFlow.exe"),"");
      using(RegistryKey key=Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall\PianoFlow")){key.SetValue("DisplayName","PianoFlow");key.SetValue("DisplayVersion","1.0.0");key.SetValue("Publisher","PianoFlow");key.SetValue("InstallLocation",appDir);key.SetValue("DisplayIcon",Path.Combine(appDir,"PianoFlow.exe"));key.SetValue("UninstallString","\""+Path.Combine(appDir,"Uninstall.exe")+"\"");key.SetValue("NoModify",1,RegistryValueKind.DWord);key.SetValue("NoRepair",1,RegistryValueKind.DWord);}
      status.Text="Установка завершена";install.Text="Запустить PianoFlow";install.Enabled=true;
    }catch(Exception ex){install.Enabled=true;status.Text="Не удалось установить";MessageBox.Show(ex.Message,"Ошибка установки",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
  }
  static class Program{[STAThread]static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new SetupForm());}}
}
