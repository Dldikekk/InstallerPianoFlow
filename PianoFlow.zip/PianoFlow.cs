using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace PianoFlow {
  class NoteEvent { public long Tick; public int Note, Velocity, Channel; public bool On; }
  class Song { public string Name; public List<NoteEvent> Events = new List<NoteEvent>(); public int Ppq=480; public int Tempo=500000; public long EndTick; }
  static class Midi {
    static int ReadInt(byte[] b,int p) { return (b[p]<<24)|(b[p+1]<<16)|(b[p+2]<<8)|b[p+3]; }
    static long Var(byte[] b,ref int p,int end) { long x=0; byte c; do { if(p>=end) throw new InvalidDataException("MIDI file is truncated."); c=b[p++]; x=(x<<7)|(uint)(c&127); } while((c&128)!=0); return x; }
    public static Song Read(string path) {
      byte[] b=File.ReadAllBytes(path); int p=0; if(b.Length<14 || Encoding.ASCII.GetString(b,0,4)!="MThd") throw new InvalidDataException("Choose a standard .mid file.");
      int h=ReadInt(b,4); int fmt=(b[8]<<8)|b[9], tracks=(b[10]<<8)|b[11], div=(b[12]<<8)|b[13]; if(h<6 || div==0 || (div&0x8000)!=0) throw new InvalidDataException("SMPTE timing is not supported.");
      Song s=new Song(); s.Ppq=div; p=8+h;
      for(int tr=0;tr<tracks && p+8<=b.Length;tr++) {
        string id=Encoding.ASCII.GetString(b,p,4); int len=ReadInt(b,p+4); p+=8; int end=Math.Min(b.Length,p+Math.Max(0,len)); if(id!="MTrk") {p=end;continue;}
        long tick=0; int running=0;
        while(p<end) {
          tick+=Var(b,ref p,end); if(p>=end) break; int st=b[p]; if(st<128) { if(running==0) throw new InvalidDataException("Invalid MIDI event."); st=running; } else {p++; if(st<0xF0) running=st;}
          if(st==0xFF) { if(p>=end) break; int type=b[p++]; long n=Var(b,ref p,end); int size=(int)Math.Min(n,end-p); if(type==0x51 && size==3 && s.Events.Count==0) s.Tempo=(b[p]<<16)|(b[p+1]<<8)|b[p+2]; p+=size; if(type==0x2F) break; continue; }
          if(st==0xF0 || st==0xF7) {long n=Var(b,ref p,end); p+=(int)Math.Min(n,end-p); continue;}
          int hi=st&0xF0,ch=st&15; if(hi==0xC0||hi==0xD0){p++;continue;} if(p+1>=end) break; int a=b[p++],v=b[p++]; if(hi==0x90||hi==0x80) s.Events.Add(new NoteEvent{Tick=tick,Note=a,Velocity=v,Channel=ch,On=(hi==0x90&&v>0)});
        }
        s.EndTick=Math.Max(s.EndTick,tick); p=end;
      }
      if(s.Events.Count==0) throw new InvalidDataException("No piano notes were found in this MIDI file.");
      s.Events.Sort((a,c)=>a.Tick.CompareTo(c.Tick)); s.Name=Path.GetFileNameWithoutExtension(path); return s;
    }
  }
  class MainForm : Form {
    [DllImport("winmm.dll")] static extern int midiOutGetNumDevs();
    [DllImport("winmm.dll")] static extern int midiOutOpen(out IntPtr h,int device,IntPtr cb,IntPtr instance,int flags);
    [DllImport("winmm.dll")] static extern int midiOutShortMsg(IntPtr h,int msg);
    [DllImport("winmm.dll")] static extern int midiOutReset(IntPtr h);
    [DllImport("winmm.dll")] static extern int midiOutClose(IntPtr h);
    IntPtr midi=IntPtr.Zero; Song song; Timer timer; Stopwatch watch=new Stopwatch(); int eventIndex; double pixelsPerSec=150; bool playing=false; string message="Open a MIDI file, or play the piano with your keyboard.";
    readonly Color bg=Color.FromArgb(15,21,31), panel=Color.FromArgb(26,35,49), accent=Color.FromArgb(43,190,151); HashSet<int> held=new HashSet<int>();
    string keys="awsedftgyhujkolp;"; int baseNote=48;
    public MainForm() {
      Text="PianoFlow — unlimited piano practice"; Width=1120; Height=760; MinimumSize=new Size(800,560); BackColor=bg; ForeColor=Color.White; DoubleBuffered=true; KeyPreview=true;
      try { Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
      var bar=new Panel{Dock=DockStyle.Top,Height=60,BackColor=panel}; Controls.Add(bar);
      Button open=Btn("Open MIDI",14); open.Click+=(a,b)=>LoadSong(); bar.Controls.Add(open);
      Button play=Btn("Play",136); play.Click+=(a,b)=>TogglePlay(); bar.Controls.Add(play);
      Button stop=Btn("Stop",240); stop.Click+=(a,b)=>StopSong(); bar.Controls.Add(stop);
      Label title=new Label{Text="PIANOFLOW",ForeColor=accent,Font=new Font("Segoe UI",15,FontStyle.Bold),AutoSize=true,Location=new Point(365,17)};bar.Controls.Add(title);
      timer=new Timer{Interval=16};timer.Tick+=(a,b)=>Tick();timer.Start();
      try { if(midiOutGetNumDevs()>0) midiOutOpen(out midi,-1,IntPtr.Zero,IntPtr.Zero,0); } catch{}
      FormClosing+=(a,b)=>{StopSong(); if(midi!=IntPtr.Zero)midiOutClose(midi);};
    }
    Button Btn(string t,int x){return new Button{Text=t,Location=new Point(x,11),Size=new Size(96,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(40,53,72),ForeColor=Color.White,Font=new Font("Segoe UI",9,FontStyle.Bold)};}
    void LoadSong(){using(OpenFileDialog d=new OpenFileDialog{Filter="MIDI files (*.mid;*.midi)|*.mid;*.midi|All files (*.*)|*.*",Title="Open a MIDI song"})if(d.ShowDialog()==DialogResult.OK)try{StopSong();song=Midi.Read(d.FileName);message="Loaded: "+song.Name+"   •   "+song.Events.Count(e=>e.On)+" notes";Invalidate();}catch(Exception ex){MessageBox.Show(ex.Message,"Couldn't open MIDI",MessageBoxButtons.OK,MessageBoxIcon.Warning);}}
    void Send(int note,int vel,int ch=0){if(midi!=IntPtr.Zero && note>=0 && note<128)midiOutShortMsg(midi,(vel>0?0x90:0x80)|(ch<<8)|(note<<8)|(Math.Max(0,Math.Min(127,vel))<<16));}
    void TogglePlay(){if(song==null){message="Open a MIDI file first. Free play is always ready.";Invalidate();return;}if(playing){playing=false;watch.Stop();}else{if(eventIndex>=song.Events.Count)eventIndex=0;playing=true;watch.Start();}Invalidate();}
    void StopSong(){playing=false;watch.Reset();eventIndex=0;if(midi!=IntPtr.Zero)midiOutReset(midi);}
    double SecAt(long tick){return tick*(song.Tempo/1000000.0)/song.Ppq;}
    void Tick(){if(playing&&song!=null){double sec=watch.Elapsed.TotalSeconds;while(eventIndex<song.Events.Count&&SecAt(song.Events[eventIndex].Tick)<=sec){var e=song.Events[eventIndex++];Send(e.Note,e.On?e.Velocity:0,e.Channel);}if(eventIndex>=song.Events.Count){playing=false;watch.Stop();}}Invalidate();}
    protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);Graphics g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
      using(var f=new Font("Segoe UI",10))using(var br=new SolidBrush(Color.FromArgb(174,188,205)))g.DrawString(message,f,br,18,76);
      int top=108,bottom=ClientSize.Height-126; if(bottom<=top)return;
      using(var br=new SolidBrush(panel))g.FillRectangle(br,0,top,ClientSize.Width,bottom-top);
      for(int i=0;i<12;i++){float y=top+i*(bottom-top)/12f;using(var p=new Pen(Color.FromArgb(37,52,70)))g.DrawLine(p,0,y,ClientSize.Width,y);using(var f=new Font("Segoe UI",8))using(var br=new SolidBrush(Color.FromArgb(105,125,147)))g.DrawString((int)(108-i*12)+"",f,br,4,y+2);}
      if(song!=null){double now=watch.Elapsed.TotalSeconds; foreach(var n in song.Events.Where(x=>x.On)){double t=SecAt(n.Tick)-now;float y=(float)(bottom-t*pixelsPerSec);if(y<top-40||y>bottom)continue;int lane=n.Note-21;float w=Math.Max(5,(ClientSize.Width-50)/88f-2);float x=25+lane*(ClientSize.Width-50)/88f;using(var br=new SolidBrush(Color.FromArgb(43,190,151)))g.FillRoundRect(br,new RectangleF(x,y-18,w,24),5);}}
      DrawKeyboard(g,bottom+8,ClientSize.Height-12);
    }
    void DrawKeyboard(Graphics g,int y,int end){int x0=20,w=ClientSize.Width-40;float keyW=w/52f;int[] white=Enumerable.Range(21,88).Where(n=>!new[]{1,3,6,8,10}.Contains(n%12)).ToArray();
      for(int k=0;k<white.Length;k++){int note=white[k];float x=x0+k*keyW;bool down=held.Contains(note);using(var br=new SolidBrush(down?accent:Color.FromArgb(231,235,240)))g.FillRectangle(br,x,y,keyW-1,end-y);using(var p=new Pen(Color.FromArgb(75,85,98)))g.DrawRectangle(p,x,y,keyW-1,end-y);if(note%12==0)using(var f=new Font("Segoe UI",7))using(var b=new SolidBrush(Color.FromArgb(70,79,92)))g.DrawString("C"+(note/12-1),f,b,x+2,end-18);}
      for(int note=22;note<=108;note++){int pc=note%12;if(!new[]{1,3,6,8,10}.Contains(pc))continue;float x=x0+(note-21)*w/88f-keyW*.30f;float bw=keyW*.62f;using(var br=new SolidBrush(held.Contains(note)?accent:Color.FromArgb(34,41,52)))g.FillRectangle(br,x,y,bw,(end-y)*.62f);}
    }
    protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);if(e.KeyCode==Keys.Space){TogglePlay();return;}char c=(char)e.KeyCode;int i=keys.IndexOf(char.ToLower(c));if(i>=0){int n=baseNote+i;if(held.Add(n))Send(n,95);Invalidate();} }
    protected override void OnKeyUp(KeyEventArgs e){base.OnKeyUp(e);int i=keys.IndexOf(char.ToLower((char)e.KeyCode));if(i>=0){int n=baseNote+i;held.Remove(n);Send(n,0);Invalidate();}}
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);int y=ClientSize.Height-12;if(e.Y<y-105)return;int n=21+(int)((e.X-20)*88.0/(ClientSize.Width-40));n=Math.Max(21,Math.Min(108,n));held.Add(n);Send(n,95);Invalidate();}
    protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);foreach(int n in held)Send(n,0);held.Clear();Invalidate();}
  }
  static class Ext { public static void FillRoundRect(this Graphics g,Brush b,RectangleF r,int radius){using(var p=new System.Drawing.Drawing2D.GraphicsPath()){float d=radius*2;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();g.FillPath(b,p);}} }
  class SplashForm : Form {
    Timer closeTimer;
    public SplashForm(){FormBorderStyle=FormBorderStyle.None;StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(620,360);BackColor=Color.FromArgb(15,21,31);DoubleBuffered=true;ShowInTaskbar=false;
      try { Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
      closeTimer=new Timer{Interval=1400};closeTimer.Tick+=(s,e)=>{closeTimer.Stop();Close();};Shown+=(s,e)=>closeTimer.Start();
    }
    protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);Graphics g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;Rectangle r=ClientRectangle;using(var b=new System.Drawing.Drawing2D.LinearGradientBrush(r,Color.FromArgb(39,72,96),Color.FromArgb(15,21,31),45))g.FillRectangle(b,r);
      using(var p=new Pen(Color.FromArgb(55,255,255,255)))g.DrawRectangle(p,0,0,Width-1,Height-1);
      using(var f=new Font("Segoe UI",27,FontStyle.Bold))using(var b=new SolidBrush(Color.White))g.DrawString("Piano",f,b,52,63);
      using(var f=new Font("Segoe UI",27,FontStyle.Bold))using(var b=new SolidBrush(Color.FromArgb(43,190,151)))g.DrawString("Flow",f,b,150,63);
      using(var f=new Font("Segoe UI",11))using(var b=new SolidBrush(Color.FromArgb(185,199,212)))g.DrawString("YOUR PIANO. YOUR MUSIC. YOUR PACE.",f,b,56,119);
      int x=58,y=185,kw=54,kh=88;for(int i=0;i<8;i++){using(var b=new SolidBrush(Color.FromArgb(238,242,246)))g.FillRectangle(b,x+i*kw,y,kw-2,kh);using(var p=new Pen(Color.FromArgb(70,81,95)))g.DrawRectangle(p,x+i*kw,y,kw-2,kh);}
      foreach(int i in new[]{0,1,3,4,5})using(var b=new SolidBrush(Color.FromArgb(31,40,54)))g.FillRectangle(b,x+(i+1)*kw-16,y,32,55);
      using(var b=new SolidBrush(Color.FromArgb(43,190,151)))g.FillEllipse(b,470,77,48,48);using(var b=new SolidBrush(Color.FromArgb(80,255,255,255)))g.FillEllipse(b,479,86,30,30);
      using(var f=new Font("Segoe UI",9))using(var b=new SolidBrush(Color.FromArgb(140,160,178)))g.DrawString("OFFLINE PIANO PRACTICE",f,b,57,312);
      using(var b=new SolidBrush(Color.FromArgb(43,190,151)))g.FillRectangle(b,57,337,190,3);
    }
  }
  static class Program { [STAThread] static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);using(var splash=new SplashForm())Application.Run(splash);Application.Run(new MainForm());} }
}
