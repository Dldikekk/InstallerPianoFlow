PianoFlow
=========

Offline Windows piano practice app inspired by falling-note piano games.
No account, subscription, or built-in song-count limit.
Includes a custom launch screen and app icon.

Start: double-click PianoFlow.exe
Installer: double-click PianoFlow-Setup.exe. It installs per-user and does not
need administrator rights. Uninstall from Windows Settings > Apps or the Start menu.

Open MIDI: choose a .mid or .midi file.
Play / Stop: use the buttons at the top.
Free play: press the computer keyboard keys A W S E D F T G Y H U J K O L P ;
           or click the piano keys at the bottom.
Space: play or pause the loaded song.

Sound is sent through the Windows MIDI output device. If the app is silent,
connect a MIDI keyboard/synthesizer or enable a software MIDI synthesizer.
MIDI playback uses the file's initial tempo. SMPTE-timed MIDI files are not
supported. The program works offline and opens standard MIDI files from disk.
