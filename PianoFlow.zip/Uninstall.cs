using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace PianoFlowUninstall {
  class UninstallForm : Form {
    string appDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","PianoFlow");
    public UninstallForm(){Text="Удаление PianoFlow";ClientSize=new Size(440,220);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(16,23,34);ForeColor=Color.White;Font=new Font("Segoe UI",10);try{Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);}catch{}
      Label title=new Label{Text="Удалить PianoFlow?",Font=new Font("Segoe UI",18,FontStyle.Bold),AutoSize=true,Location=new Point(28,27)};Controls.Add(title);
      Label info=new Label{Text="Приложение и его ярлыки будут удалены с этого компьютера.",AutoSize=false,Size=new Size(380,50),Location=new Point(30,76),ForeColor=Color.FromArgb(185,201,215)};Controls.Add(info);
      Button cancel=new Button{Text="Отмена",Location=new Point(198,151),Size=new Size(96,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(40,53,72),ForeColor=Color.White};cancel.Click+=(s,e)=>Close();Controls.Add(cancel);
      Button remove=new Button{Text="Удалить",Location=new Point(310,151),Size=new Size(96,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(195,76,86),ForeColor=Color.White,Font=new Font("Segoe UI",9,FontStyle.Bold)};remove.Click+=(s,e)=>Remove();Controls.Add(remove);
    }
    void Remove(){try{string menu=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"PianoFlow");if(Directory.Exists(menu))Directory.Delete(menu,true);string desktop=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"PianoFlow.lnk");if(File.Exists(desktop))File.Delete(desktop);using(RegistryKey k=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall",true))if(k!=null)k.DeleteSubKeyTree("PianoFlow",false);
      string script=Path.Combine(Path.GetTempPath(),"PianoFlow-remove-"+Guid.NewGuid().ToString("N")+".cmd");string dir=appDir.Replace("%","%%");File.WriteAllText(script,"@echo off\r\nping 127.0.0.1 -n 3 >nul\r\nrmdir /s /q \""+dir+"\"\r\ndel \"%~f0\"\r",Encoding.ASCII);Process.Start(new ProcessStartInfo("cmd.exe","/c \""+script+"\""){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden});Close();
    }catch(Exception ex){MessageBox.Show(ex.Message,"Ошибка удаления",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
  }
  static class Program{[STAThread]static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new UninstallForm());}}
}
